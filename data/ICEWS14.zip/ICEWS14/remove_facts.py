import numpy as np
import os
import random

cut_prop=0.3

f=open('train.txt', 'r')
TKG={}
for line in f:
    line_split = line.split('\t')
    head = int(line_split[0])
    rel = int(line_split[1])
    tail = int(line_split[2])
    t = int(line_split[3])
    if t not in TKG.keys():
        TKG[t]=[]
    else:
        TKG[t].append([head, rel, tail, t])

for t in TKG.keys():
    random.shuffle(TKG[t])
    length = len(TKG[t])
    keep_length = int((1-cut_prop)*length)
    if keep_length == 0:
        keep_length = length
    TKG[t] = TKG[t][:keep_length]

f=open('train_uncomplete_prop_'+str(cut_prop)+'.txt', 'w')
for t in TKG.keys():
    for fact in TKG[t]:
        f.write('\t'.join([str(e) for e in fact])+'\n')
